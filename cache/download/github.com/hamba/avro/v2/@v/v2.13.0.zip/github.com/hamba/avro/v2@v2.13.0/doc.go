// Package avro implements encoding and decoding of Avro as defined by the Avro specification.
//
// See the Avro specification for an understanding of Avro: http://avro.apache.org/docs/current/
package avro
