---
name: Blank Issue
about: Create an issue with a blank template.
---
